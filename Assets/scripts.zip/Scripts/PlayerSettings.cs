using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerSettings
{
    public Color deck = new Color(0.745f, 0.005f, 0.017f, 1);
    public Color wheels = new Color(0.745f, 0.683f, 0.455f, 1);
    public Color trucks = new Color(0.26f, 0.26f, 0.26f, 1);
    public GameObject character;
    public bool hasPlayed;


}
