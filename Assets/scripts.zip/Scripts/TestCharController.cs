using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.ParticleSystem;

public class TestCharController : MonoBehaviour {
    public float movementSpeed = 20.0f;
    public SpawnManager spawnManager;
    public PlayerManager playerManager;

    public float hMovement;
    public float vMovement;
    public float hInput = 0;
    [SerializeField]
    Vector3 jump= Vector3.up*2;
    [SerializeField]
    public float jumpForce = 6;
    public GameObject model;
    public float timecount;
    Vector3 oldPos;
    bool land=true;
    bool isGrinding;
    int level ;
    public  bool isKicking;



    public GameObject skateboard;
    public GameObject frenchfry;
    Animator skateAnim;
    Animator fryAnim;
    Rigidbody rb;

    void Start() {
        rb = GetComponent<Rigidbody>();
        skateAnim = skateboard.GetComponent<Animator>();
        fryAnim = frenchfry.GetComponent<Animator>();
        playerManager = gameObject.GetComponent<PlayerManager>();
        level = PlayerPrefs.GetInt("level");
    }

    void Update() {

        //if (!playerManager.isGameStarted)
       //    return; 
        
        if (playerManager.isInControl&&!isGrinding) {
            float time = 4f * Time.deltaTime;
            int frameTouches = 0;
            foreach (Touch touch in Input.touches) {
               
                if (touch.phase == TouchPhase.Began|| touch.phase == TouchPhase.Stationary) {
                    if (touch.position.x < Screen.width/2)
                        hInput = hInput - time;
                    if (touch.position.x > Screen.width/2)
                        hInput = hInput + time;
                }
                frameTouches++;
                    
            }
            if (frameTouches == 0) {
                if (hInput > 0)
                    hInput = hInput - time;
                if (hInput < 0)
                    hInput = hInput + time;

            }
            hInput = Mathf.Clamp(hInput, -1.0f, 1.0f);
            //Debug.Log(hInput); remove this line before luanching pls vvvvvvvvvvvvvvvvvs
            hInput = Input.GetAxis("Horizontal");
        }
        hMovement = hInput * movementSpeed / 2;
        vMovement = movementSpeed;
        if (isGrinding)
            hInput = 0;
        if (Mathf.Abs(transform.position.x) > 7.5f) {
            transform.position = new Vector3(Mathf.Clamp(transform.position.x, -7.5f, 7.5f), oldPos.y, oldPos.z);
            transform.Translate(new Vector3(0, 0, vMovement) * Time.deltaTime);
            
        }
        else if (isGrounded()&&!isGrinding) {
            transform.Translate(new Vector3(hMovement, 0, vMovement) * Time.deltaTime);
            if (playerManager.isInControl)
                transform.eulerAngles = new Vector3(0, hInput * 10f, 0);
        } else {
            transform.Translate(new Vector3(hMovement/5, 0, vMovement) * Time.deltaTime);
            transform.eulerAngles = new Vector3(0, hInput * 10f/5f, 0);
        }

        if (playerManager.isGameStarted) {
            if ((SwipeManager.IsSwipingUp() || Input.GetButtonDown("Jump")) && (isGrounded() || isGrinding || isKicking)) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Jump");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
                
            }

            if (SwipeManager.IsSwipingLeft() && (isGrounded() || isGrinding || isKicking) && level>=2) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Pop Shuv");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingUpLeft() && (isGrounded() || isGrinding || isKicking) && level >=3) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Kickflip");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingRight() && (isGrounded() || isGrinding || isKicking) && level >=4) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("FS Shuv");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingUpRight() && (isGrounded() || isGrinding || isKicking) && level >=5) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Heelflip");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingDown() && (isGrounded() || isGrinding || isKicking) && level >=6) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Nollie");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingDownLeft() && (isGrounded() || isGrinding || isKicking) && level >=7) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Nollie Flip");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }

            if (SwipeManager.IsSwipingDownRight() && (isGrounded() || isGrinding || isKicking) && level >=8) {
                EndGrind();
                rb.constraints = RigidbodyConstraints.None;
                rb.AddForce(jump * jumpForce, ForceMode.Impulse);
                skateAnim.SetTrigger("Nollie Heel");
                fryAnim.SetTrigger("Jump");
                FindObjectOfType<AudioManager>().PlaySound("Jump");
                if (playerManager.hasJumpBoost)
                    FindObjectOfType<AudioManager>().PlaySound("Boing");
                land = false;
            }   
        }

        //if (isGrounded() && land == false) {
          //  FindObjectOfType<AudioManager>().PlaySound("Land");
           // land = true;

       //}
       if ((isGrounded() || isGrinding ) && !FindObjectOfType<AudioManager>().sounds[2].source.isPlaying) {
            FindObjectOfType<AudioManager>().PlaySound("Skate");
            if (land == false) 
            FindObjectOfType<AudioManager>().PlaySound("Land");
        } else if (!isGrounded() && !isGrinding) {
            FindObjectOfType<AudioManager>().StopSound("Skate");
       }
        oldPos = transform.position;
        
    }


    public bool isGrounded() {
        return Physics.Raycast(transform.position, Vector3.down, 0.01f);
    }

    private void OnTriggerEnter(Collider collider) {
        if (collider.CompareTag("SpawnTrigger")) {
            spawnManager.SpawnTriggerEntered();
            movementSpeed += 0.25f;
        }
        if ((collider.CompareTag("Grindable")) && playerManager.isAlive && !isGrounded()) {
            GrindSurface(collider.gameObject);
        }
        if ((collider.CompareTag("Launch")) && playerManager.isAlive) {
            jump = Vector3.up*2f;
        }

    }

    private void OnTriggerExit(Collider other) {
        if (other.CompareTag("Launch") && playerManager.isAlive) {
            jump = Vector3.up;
        }
    }

    public void OnCollisionEnter(Collision collider) {
        if (collider.gameObject.CompareTag("Grindable") && playerManager.isAlive && !isGrounded()) {
            GrindSurface(collider.gameObject);
        } else if (collider.gameObject.CompareTag("Kicker") && playerManager.isAlive) {
            StartCoroutine("Kick");
        }
                        
    }

    public void OnCollisionExit(Collision collider) {
        if ((collider.gameObject.CompareTag("Grindable")) && playerManager.isAlive) {
            EndGrind();
        }
    }

    public IEnumerator Kick() {
        isKicking = true;
        yield return new WaitForSeconds(0.5f);
        isKicking = false;
    }
    void GrindSurface(GameObject surface) {

        playerManager.isInControl = false;
        isGrinding = true;
        rb.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezeRotationX;
        transform.position = new Vector3(surface.transform.position.x, surface.transform.position.y, transform.position.z); 
        transform.eulerAngles = new Vector3 (transform.eulerAngles.x,0,transform.eulerAngles.z);
        fryAnim.SetTrigger("Grind");
        int grindChance = Random.Range(8, Mathf.Clamp(level+1,8,15));
        switch (grindChance) {
            case 8:
                skateAnim.SetBool("50-50", true);
                break;
            case 9:
                skateAnim.SetBool("5-0", true);
                break;
            case 10:
                skateAnim.SetBool("Nosegrind", true);
                break;
            case 11:
                if (Random.Range(0, 2) == 0) {
                    skateAnim.SetBool("leftCrooked", true);
                } else {
                    skateAnim.SetBool("rightCrooked", true);
                }
                    break;
            case 12:
                if (Random.Range(0, 2) == 0) {
                    skateAnim.SetBool("Salad", true);
                }
                else {
                    skateAnim.SetBool("Suski", true);
                }
                break;
            case 13:
                if (Random.Range(0, 2) == 0) {
                    skateAnim.SetBool("Feeble", true);
                }
                else {
                    skateAnim.SetBool("Smith", true);
                }
                break;
            case 14:
                if (Random.Range(0, 2) == 0) {
                    skateAnim.SetBool("Willy", true);
                }
                else {
                    skateAnim.SetBool("OverWilly", true);
                }
                break;


        }
    }
    void EndGrind() {
        playerManager.isInControl = true;
        isGrinding = false;
        skateAnim.SetBool("5-0", false);
        skateAnim.SetBool("50-50", false);
        skateAnim.SetBool("Nosegrind", false);
        skateAnim.SetBool("leftCrooked", false);
        skateAnim.SetBool("rightCrooked", false);
        skateAnim.SetBool("Salad", false);
        skateAnim.SetBool("Suski", false);
        skateAnim.SetBool("Feeble", false);
        skateAnim.SetBool("Smith", false);
        skateAnim.SetBool("Willy", false);
        skateAnim.SetBool("OverWilly", false);
        rb.constraints = RigidbodyConstraints.None;;
    }


}
