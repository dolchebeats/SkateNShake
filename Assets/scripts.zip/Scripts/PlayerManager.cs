using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
//using static UnityEditor.Progress;

public class PlayerManager : MonoBehaviour {
    bool gameOver;
    public TestCharController testCharController;
    public GameObject gameplayPanel;
    public GameObject gameOverPanel;
    public GameObject startPanel;
    public GameObject newLevelPanel;
    public GameObject shopPanel;
    public GameObject fries;
    public GameObject skateboard;
    public GameObject mainCamera;
    public int coins;
    public TMP_Text stats;
    public TMP_Text endScore;
    public TMP_Text startScore;
    public TMP_Text newLevelText;
    public GameObject levelBarGO;
    public GameObject newSticker;
    public Slider levelBar;
    public TMP_Text levelBarText;
    public int distance;
    public bool isAlive;
    public  bool isGameStarted;
    public Animator cameraAnim;
    public Animator fryAnim;
    public Animator skateAnim;
    public  bool isInControl = false;

    public int coinMultiplier=1;

    public int wallet;
    public int totalDistance;
    public int level;
    public int levelDistance;
    public int highScore;

    public bool hasJumpBoost;
    public bool hasCoin3x;
    public bool hasStopwatch;
    public int timerJumpBoost;
    public int timerCoin3x;
    public int timerStopwatch;
    public GameObject sliderJumpBoost;
    public GameObject sliderCoin3x;
    public GameObject sliderStopwatch;

    private void Start() {
        wallet = PlayerPrefs.GetInt("wallet");
        totalDistance = PlayerPrefs.GetInt("totalDistance");
        level = PlayerPrefs.GetInt("level");
        if (level == 0)
            level = 1;
        levelDistance = PlayerPrefs.GetInt("levelDistance");

        highScore = PlayerPrefs.GetInt("highScore");
        startScore.text = "COINS: " + wallet + " COINS\nHIGH SCORE: " + highScore + "ft";

        levelBarText.text = "LEVEL " + level;
        levelBar = levelBarGO.GetComponent<Slider>();
        levelBar.value = levelDistance;

        testCharController = GetComponent<TestCharController>();
        stats.text = null;
        Time.timeScale = 1.0f;
        isAlive = true;
        isGameStarted = false;
        fryAnim = fries.GetComponent<Animator>();
        cameraAnim = mainCamera.GetComponent<Animator>();
        skateAnim = skateboard.GetComponent<Animator>();
        GetComponent<TestCharController>().enabled = false;
        mainCamera.GetComponent<TestCamController>().enabled = false;
        Physics.gravity = new Vector3(0, -20f, 0);
        startPanel.SetActive(true);
        if (PlayerPrefs.GetInt("newLevel") == 1) {
            ShowLevelReward(level);
        }
    }

    private void Update() {


            distance = Mathf.RoundToInt(transform.position.z) / 10;
            stats.text = "COINS: " + coins + "\nSCORE: " + distance + "ft" + "\nHIGH SCORE: " + highScore + "ft";

        if (SwipeManager.isTapping() && isGameStarted == false) {            
            StartingAnimation(); 
        }


    }

    private void OnEnable() {
        wallet = PlayerPrefs.GetInt("wallet");
        startScore.text = "COINS: " + wallet + " COINS\nHIGH SCORE: " + highScore + "ft";
    }
    public void OnTriggerEnter(Collider item) {
        if (item.gameObject.tag == "Coin") {
            coins = coins + 1 * coinMultiplier;
            Destroy(item.gameObject);
            FindObjectOfType<AudioManager>().PlaySound("Coin");

        } else if (item.gameObject.tag == "Stopwatch") {
            Destroy(item.gameObject);
            FindObjectOfType<AudioManager>().PlaySound("ClockTick");
            StopCoroutine("Stopwatch");
            StartCoroutine("Stopwatch");
        } else if (item.gameObject.tag == "Coin3x") {
            Destroy(item.gameObject);
            FindObjectOfType<AudioManager>().PlaySound("Coin");
            StopCoroutine("Coin3x");
            StartCoroutine("Coin3x");

        } else if (item.gameObject.tag == "JumpBoost") {
            Destroy(item.gameObject);
            FindObjectOfType<AudioManager>().PlaySound("Boing");
            StopCoroutine("JumpBoost");
            StartCoroutine("JumpBoost");

        }
    }

    public void OnCollisionEnter(Collision collider) {
        if ((collider.gameObject.tag == "Obstacle") && isAlive) {
            PlayerDeath();
            
        }
        
    }  

    public IEnumerator Stopwatch() {
        hasStopwatch = true;
        sliderStopwatch.gameObject.GetComponent<Slider>().value = 15;
        sliderStopwatch.gameObject.SetActive(true);
        Time.timeScale = 0.5f;
        FindObjectOfType<AudioManager>().ChangePitch(0.5f);
        //yield return new WaitForSeconds(7.5f);
        timerStopwatch = 15;
        for (int i = 0; i < 15; i++) {
            yield return new WaitForSeconds(0.5f);
            timerStopwatch--;
            sliderStopwatch.gameObject.GetComponent<Slider>().value = timerStopwatch;
        }
        if (Time.timeScale == 0.5f && isAlive) {
            Time.timeScale = 1f;
            FindObjectOfType<AudioManager>().ChangePitch(1f);
        }
        sliderStopwatch.gameObject.SetActive(false);
        hasStopwatch=false;
    }

    public IEnumerator Coin3x() {
        hasCoin3x = true;
        coinMultiplier = 3;
        sliderCoin3x.gameObject.GetComponent<Slider>().value = 15;
        sliderCoin3x.gameObject.SetActive(true);
        //yield return new WaitForSeconds(15);
        timerCoin3x = 15;
        for (int i = 0; i < 15; i++) {
            yield return new WaitForSeconds(1);
            timerCoin3x--;
            sliderCoin3x.gameObject.GetComponent<Slider>().value = timerCoin3x;
        }
        sliderCoin3x.gameObject.SetActive(false);
        coinMultiplier = 1;
        hasCoin3x=false;
    }
    public IEnumerator JumpBoost() {
        hasJumpBoost = true;
        testCharController.jumpForce = 9f;
        sliderJumpBoost.gameObject.GetComponent<Slider>().value = 15;
        sliderJumpBoost.gameObject.SetActive(true);
        //yield return new WaitForSeconds(15);
        timerJumpBoost = 15;       
        for (int i = 0; i < 15;  i++) {
            yield return new WaitForSeconds(1);
            timerJumpBoost--;
            sliderJumpBoost.gameObject.GetComponent<Slider>().value = timerJumpBoost;
        }        
        testCharController.jumpForce = 6f;
        sliderJumpBoost.gameObject.SetActive(false);
        hasJumpBoost =false;
    }
    public void PlayerDeath() {
        isAlive = false;
        FindObjectOfType<AudioManager>().ChangePitch(1f);
        PlayerPrefs.SetInt("wallet", wallet + coins);
        PlayerPrefs.SetInt("totalDistance", totalDistance + distance);
        if (distance > highScore) {
            highScore = distance;
            newSticker.SetActive(true);
        }
        PlayerPrefs.SetInt("highScore", highScore);
        levelDistance = levelDistance + distance;
        while (levelDistance >= 1000) {
            levelDistance -= 1000;
            level++;
            PlayerPrefs.SetInt("newLevel", 1);
        }
        PlayerPrefs.SetInt("levelDistance", levelDistance);
        PlayerPrefs.SetInt("level", level);

        endScore.text = "SCORE: " + distance + "ft\nHIGH SCORE: " + highScore + "ft"; 

        FindObjectOfType<AudioManager>().StopSound("Skate");
        FindObjectOfType<AudioManager>().TapeStop("MainTheme");
        FindObjectOfType<AudioManager>().PlaySound("GameOver");
       // gameOver = true;
        Destroy(skateboard.GetComponent<Animator>());
        skateboard.AddComponent<BoxCollider>();
        skateboard.AddComponent<Rigidbody>();
        skateboard.GetComponent<Rigidbody>().AddForce(transform.up * 20);
        Destroy(fries.GetComponent<Animator>());
        fries.AddComponent<Rigidbody>();
        fries.AddComponent<BoxCollider>();
        for (int i = 0; i < fries.transform.childCount; i++) {
            fries.transform.GetChild(i).gameObject.AddComponent<Rigidbody>();
            fries.transform.GetChild(i).gameObject.AddComponent<BoxCollider>();
        }
        GetComponent<TestCharController>().enabled = false;
        GetComponent<Rigidbody>().useGravity = false;
        GetComponent<Rigidbody>().isKinematic = true;

        Time.timeScale = 0.25f;
        gameplayPanel.SetActive(false);
        gameOverPanel.SetActive(true);
    }  
    public IEnumerator StartGame() {
        FindObjectOfType<AudioManager>().sounds[0].source.volume = FindObjectOfType<AudioManager>().sounds[0].source.volume / 2;
        
 
        startPanel.SetActive(false);
        cameraAnim.SetTrigger("Start");
        GetComponent<TestCharController>().enabled = true;
        isInControl = false;
        mainCamera.GetComponent<TestCamController>().enabled = true;
        fryAnim.SetTrigger("Start");
        skateAnim.SetTrigger("Start");
        
        yield return new WaitForSeconds(1);
        isGameStarted = true;
        isInControl = true;
        gameplayPanel.SetActive(true);
        
    }
    public void StartingAnimation() {
        StartCoroutine("StartGame");
    }

    void ShowLevelReward(int level) {
        startPanel.SetActive(false);
        newLevelPanel.SetActive(true);
        switch (level) {
            case 2:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nPOP SHUV\r\n\r\nSWIPE LEFT";
                break;
            case 3:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nKICKFLIP\r\n\r\nSWIPE UP-LEFT";
                break;
            case 4:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nFS SHUV\r\n\r\nSWIPE RIGHT";
                break;
            case 5:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nHEELFLIP\r\n\r\nSWIPE UP-RIGHT";
                break;
            case 6:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nNOLLIE\r\n\r\nSWIPE DOWN";
                break;
            case 7:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nNOLLIE FLIP\r\n\r\nSWIPE DOWN-LEFT";
                break;
            case 8:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nNOLLIE HEEL\r\n\r\nSWIPE DOWN-RIGHT";
                break;
            case 9:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\n5-0\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            case 10:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nNOSEGRIND\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            case 11:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nCROOKED GRIND\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            case 12:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nSALAD/SUSKI GRIND\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            case 13:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nFEEBLE/SMITH GRIND\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            case 14:
                newLevelText.text = "NEW TRICK LEARNED!\r\n\r\nWILLY GRIND\r\n\r\nGRIND A RAIL OR LEDGE";
                break;
            default:
                newLevelText.text = "LEVEL UP!\r\n\r\nLEVEL " + level;
                break;

        }
    }

    public void EndLevelReward () {
        startPanel.SetActive(true);
        newLevelPanel.SetActive(false);
        PlayerPrefs.SetInt("newLevel", 0);
    }

    public void ShowShop() {
        startPanel.SetActive(false);
        shopPanel.SetActive(true);
    }

    public void HideShop() {
        wallet = PlayerPrefs.GetInt("wallet");
        startScore.text = "COINS: " + wallet + " COINS\nHIGH SCORE: " + highScore + "ft";
        startPanel.SetActive(true);
        shopPanel.SetActive(false);
    }
}
