using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ShopManager : MonoBehaviour {
    public int wallet;
    public TMP_Text walletText;
    public ShopItemSO[] shopItemsSO;
    public GameObject[] shopPanelsGO;
    public ShopTemplate[] shopPanels;
    public Button[] buyBtn;
    public GameObject player;
    public PlayerManager playerManager;
    public Material deck, trucks, wheels;
    public PlayerSettings PSET;
    public GameObject deckStock;
    public GameObject truckStock;
    public GameObject wheelStock;
    public Material stockColor;
    public string json;

    private void Start() {
        //StartCoroutine("takeShopImage");
        PlayerPrefs.SetInt("hasRedDeck", 1);
        PlayerPrefs.SetInt("hasSilverTrucks", 1);
        PlayerPrefs.SetInt("hasCreamWheels", 1);

        playerManager = player.GetComponent<PlayerManager>();
        for (int i = 0; i < shopItemsSO.Length; i++) {
            shopPanelsGO[i].gameObject.SetActive(true);
        }
        wallet = PlayerPrefs.GetInt("wallet");
        RefreshUI();
    }

    public void RefreshUI() {
        PSET = SaveManager.LoadData();
        deck.color = PSET.deck;
        trucks.color = PSET.trucks;
        wheels.color = PSET.wheels;
        walletText.text = "SKATESHOP\nCOINS: " + wallet;

        for (int i = 0; i < shopItemsSO.Length; i++) {
            shopPanels[i].titleText.text = shopItemsSO[i].title;
            shopPanels[i].image.sprite = Resources.Load<Sprite>(shopItemsSO[i].name);
            shopPanels[i].cost.text = shopItemsSO[i].cost + " COINS";

            if (wallet >= shopItemsSO[i].cost) {
                buyBtn[i].interactable = true;
            } else {
                buyBtn[i].interactable = false;
            }
            if (PlayerPrefs.GetInt("has" + shopItemsSO[i].name) == 1) {
                shopPanels[i].cost.text = "OWNED";
                buyBtn[i].interactable = true;
            }
            if (PlayerPrefs.GetString("equippedDeck") == shopItemsSO[i].name || PlayerPrefs.GetString("equippedWheels") == shopItemsSO[i].name ||
                PlayerPrefs.GetString("equippedTrucks") == shopItemsSO[i].name || PlayerPrefs.GetString("equippedCharacter") == shopItemsSO[i].name) {
                shopPanels[i].cost.text = "USING";
                buyBtn[i].interactable = false;
            }
        }


    }

    public void PurchaseItem(int btnNo) {
        if (PlayerPrefs.GetInt("has" + shopItemsSO[btnNo].name) == 1) {
            if (shopItemsSO[btnNo].type == "deck") {
                PlayerPrefs.SetString("equippedDeck", shopItemsSO[btnNo].name);
                PSET.deck = shopItemsSO[btnNo].rgb;
            }
            if (shopItemsSO[btnNo].type == "wheels") {
                PlayerPrefs.SetString("equippedWheels", shopItemsSO[btnNo].name);
                PSET.wheels = shopItemsSO[btnNo].rgb;
            }
            if (shopItemsSO[btnNo].type == "trucks") {
                PlayerPrefs.SetString("equippedTrucks", shopItemsSO[btnNo].name);
                PSET.trucks = shopItemsSO[btnNo].rgb;
            }
            if (shopItemsSO[btnNo].type == "character") {
                PlayerPrefs.SetString("equippedCharacter", shopItemsSO[btnNo].name);
                //PSET.character = new GameObject 
            }
        } else if (wallet >= shopItemsSO[btnNo].cost) {
            wallet = wallet - shopItemsSO[btnNo].cost;
            PlayerPrefs.SetInt("has" + shopItemsSO[btnNo].name, 1);
            if (PlayerPrefs.GetInt("has" + shopItemsSO[btnNo].name) == 1) {
                if (shopItemsSO[btnNo].type == "deck") {
                    PlayerPrefs.SetString("equippedDeck", shopItemsSO[btnNo].name);
                    PSET.deck = shopItemsSO[btnNo].rgb;
                }
                if (shopItemsSO[btnNo].type == "wheels") {
                    PlayerPrefs.SetString("equippedWheels", shopItemsSO[btnNo].name);
                    PSET.wheels = shopItemsSO[btnNo].rgb;
                }
                if (shopItemsSO[btnNo].type == "trucks") {
                    PlayerPrefs.SetString("equippedTrucks", shopItemsSO[btnNo].name);
                    PSET.trucks = shopItemsSO[btnNo].rgb;
                }
                if (shopItemsSO[btnNo].type == "character") {
                    PlayerPrefs.SetString("equippedCharsacter", shopItemsSO[btnNo].name);
                }
            }
        }
        PlayerPrefs.SetInt("wallet", wallet);
        SaveManager.SaveData(PSET);
        RefreshUI();
    }
}
    /*public IEnumerator takeShopImage() {
        for (int i = 0; i < shopItemsSO.Length; i++) {
            //yield return new WaitForEndOfFrame();
            string type = ptype;
            type = shopItemsSO[i].type;
            Color rgb = shopItemsSO[i].rgb;
            GameObject stock = null;

            Texture2D texture = new Texture2D(1024, 1024, TextureFormat.ARGB32, false);
            Rect rect = new Rect(0, 0, 1024, 1024);
            if (type == "deck") {
                stock = deckStock;
            }
            else if (type == "trucks") {
                stock = truckStock;
            }
            else if (type == "wheels") {
                stock = wheelStock;
            }
            GameObject objectToDestroy = Instantiate(stock);
            Camera camera = stock.GetComponentInChildren<Camera>();
            stockColor.color = rgb;
            RenderTexture renderTexture = new RenderTexture(1024, 1024, 24);
            camera.targetTexture = renderTexture;

            camera.Render();
            RenderTexture currentRenderTexture = RenderTexture.active;
            RenderTexture.active = renderTexture;
            texture.ReadPixels(rect, 0, 0);
            texture.Apply();
            byte[] bytes = texture.EncodeToPNG();
            File.WriteAllBytes(Application.dataPath + "/Screenshots/" + shopItemsSO[i].name + ".png", bytes);
            camera.targetTexture = null;
            RenderTexture.active = currentRenderTexture;
            Destroy(renderTexture);
            Destroy(objectToDestroy);
            psprite = Sprite.Create(texture, rect, Vector2.zero);
            sscounter++;
            yield return new WaitForEndOfFrame();
        }

        //return sprite;
    }

    public Sprite TakeShopImage(string type, Color rgb) {
        Sprite sprite=null;
        ptype = type;
        prgb = rgb;
        
        return psprite;
    }
}*/
