using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public Sound[] sounds;
    public float tapeSpeed = .25f;
    bool tapestop;
    void Start()
    {
        foreach (Sound s in sounds) {
            s.source = gameObject.AddComponent<AudioSource>();
            int i = Random.Range(0, s.clip.Length);
            s.source.clip = s.clip[i];
            s.source.loop = s.loop;
            s.source.volume = s.volume;
            s.source.pitch = s.pitch;


        }

        PlaySound("MainTheme");
    }

    private void Update() {
        if (sounds[0].source.pitch > 0 && tapestop) {
            sounds[0].source.pitch -= Time.deltaTime * 10;
            if (sounds[0].source.pitch < 0.1f)
                sounds[0].source.pitch = 0;
        }


    }
    public void PlaySound(string name)
    {
        foreach (Sound s in sounds) {
            if(s.name == name) {
                s.source.Play();
            }
        }
    }

    public void StopSound(string name) {
        foreach (Sound s in sounds) {
            if (s.name == name) {
                s.source.Stop();
            }
        }
    }
    public void TapeStop(string name) {
        tapestop=true;
    }

    public void ChangePitch(float speed) {
        foreach (Sound s in sounds) {
            s.source.pitch = speed;
        }
    }
}
