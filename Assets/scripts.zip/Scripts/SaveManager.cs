using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
//using UnityEngine.Windows;

public class SaveManager
{
    public static string directory = "/SaveData/";
    public static string fileName = "data.txt";
    public static PlayerSettings PSETdefault = new PlayerSettings();

    public static void SaveData(PlayerSettings PSET) {
        string dir = Application.persistentDataPath + directory;
        if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        string json = JsonUtility.ToJson(PSET);
        File.WriteAllText(dir + fileName, json);
    }

    public static PlayerSettings LoadData() {
        PSETdefault.deck = new Color(0.745f, 0.005f, 0.017f, 1);
        PSETdefault.trucks = new Color(0.26f, 0.26f, 0.26f, 1);
        PSETdefault.wheels = new Color(0.745f, 0.683f, 0.455f, 1);
        string fullPath = Application.persistentDataPath + directory + fileName;
        PlayerSettings PSET = new PlayerSettings();
        if(File.Exists(fullPath)) {
            string json  = File.ReadAllText(fullPath);
            PSET = JsonUtility.FromJson<PlayerSettings>(json);
        } else {
            PSET = PSETdefault;
        }
        if (PSET.hasPlayed == false) {
            PSET = PSETdefault;
        }
        PSET.hasPlayed = true;
        SaveData(PSET);
        return PSET;
    }
}
